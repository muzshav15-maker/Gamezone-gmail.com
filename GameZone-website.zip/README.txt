GAMEZONE WEBSITE

1. Upload index.html to a GitHub repository.
2. Enable GitHub Pages in Settings > Pages.
3. Replace the four Play button links with game URLs you are authorized to embed/link.
4. For a custom domain, connect your domain through GitHub Pages.

Site name: GameZone
